#Building package locally
python setup.py sdist'

## installing this package from github
pip install git+https://github.com/Sixolile/Sixolile-root-folder.git

## update this package from github
pip install --upgrade git+https://github.com/Sixolile/Sixolile-root-folder.git

python setup.py sdist
